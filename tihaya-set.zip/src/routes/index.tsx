import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";

export const Route = createFileRoute("/")({ component: Home });

const TG = "https://t.me/";

const MODELS = [
  { src: "/routers/40Wdr.png", name: "Keenetic", line: "Пять антенн. Стоит в комнате и не спорит с интерьером." },
  { src: "/routers/fLPwk.png", name: "Titan", line: "Тот же характер, когда нужно больше запаса." },
  { src: "/routers/RCtMK.png", name: "Дом", line: "Спереди и сзади: порты, антенны, ничего лишнего." },
];

function Home() {
  const spot = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    if (!fine) return;
    const onMove = (e: PointerEvent) => {
      if (spot.current) {
        spot.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      }
      if (stage.current) {
        const r = stage.current.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        stage.current.style.transform = `translate(${x * -16}px, ${y * -12}px)`;
      }
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <main>
      <div className="grain" aria-hidden />
      <div className="spot" ref={spot} aria-hidden />

      <header className="nav">
        <div className="mark">
          <i />
          Keenetic
        </div>
        <a className="pill" href={TG} target="_blank" rel="noreferrer">
          В чат
        </a>
      </header>

      <section className="hero">
        <div>
          <p className="kicker">От людей — для людей</p>
          <h1 className="display">
            Сеть,
            <br />
            которая
            <br />
            <em>молчит</em>
          </h1>
          <p className="lede">
            Keenetic и Netcraze. Защищённый канал поднимается на роутере —
            телевизор, приставка и гости идут сами. Банки остаются как были.
          </p>
          <div className="cta-row">
            <a className="btn-signal" href={TG} target="_blank" rel="noreferrer">
              Открыть Telegram
            </a>
            <a className="btn-ghost" href="#models">
              Смотреть модели
            </a>
          </div>
        </div>
        <div className="hero-stage">
          <img ref={stage} src="/routers/40Wdr.png" alt="Белый роутер Keenetic" />
        </div>
      </section>

      <div className="ticker" aria-hidden>
        <div className="ticker-track">
          {Array.from({ length: 2 }).map((_, i) => (
            <span key={i}>
              стабильность <b>/</b> один раз настроил <b>/</b> весь дом <b>/</b> wireguard в прошивке <b>/</b> без
              приложений на каждом <b>/</b> от людей для людей <b>/</b>
            </span>
          ))}
        </div>
      </div>

      <section className="section" id="how">
        <h2>
          Ничего
          <br />
          лишнего
        </h2>
        <div className="rows">
          <article className="row">
            <span>01</span>
            <h3>В прошивке</h3>
            <p>WireGuard и OpenVPN уже внутри KeeneticOS. Без сторонних сборок и шаманства.</p>
          </article>
          <article className="row">
            <span>02</span>
            <h3>Весь дом</h3>
            <p>Канал живёт на роутере. Устройства не знают, что им что-то ставили.</p>
          </article>
          <article className="row">
            <span>03</span>
            <h3>Только нужное</h3>
            <p>Маршрут можно сузить: отдельные сервисы, отдельная сеть, отдельное устройство.</p>
          </article>
          <article className="row">
            <span>04</span>
            <h3>Люди рядом</h3>
            <p>В чате — готовые подходы и живые ответы. Без лендингового шума.</p>
          </article>
        </div>
      </section>

      <figure className="studio">
        <img src="/routers/RCtMK.png" alt="Keenetic спереди и сзади" />
        <figcaption>
          Для дома.
          <br />
          Не для витрины.
        </figcaption>
      </figure>

      <section className="section" id="models">
        <h2>Железо</h2>
        <p className="lede">Листай. Это реальные корпуса.</p>
      </section>
      <div className="gallery">
        {MODELS.map((m) => (
          <article className="card" key={m.name}>
            <img src={m.src} alt={`Роутер ${m.name}`} />
            <div>
              <strong>{m.name}</strong>
              <p>{m.line}</p>
            </div>
          </article>
        ))}
      </div>

      <section className="path" aria-label="Сигнал проходит сквозь препятствия">
        <p className="kicker">Путь</p>
        <h2>
          Стена
          <br />
          рассыпается
        </h2>
        <div className="wall" aria-hidden>
          <div className="bars">
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
          <div className="beam" />
        </div>
        <p>Сигнал идёт. Препятствия не держатся.</p>
      </section>

      <section className="finale">
        <p className="kicker">Чат</p>
        <h2 className="display">
          Заходи.
          <br />
          Там уже
          <br />
          настроили.
        </h2>
        <div className="cta-row">
          <a className="btn-signal" href={TG} target="_blank" rel="noreferrer">
            Перейти в Telegram
          </a>
        </div>
      </section>
    </main>
  );
}
